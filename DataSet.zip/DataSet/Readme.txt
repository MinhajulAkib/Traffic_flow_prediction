This is data about traffic flow.
5 minutes time span.
Paper��LSTM Based Traffic Flow Prediction with Missing Data
